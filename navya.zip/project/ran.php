<?php
	
		$n="hi";

		$n1=$n.rand(100000,1000000);

		echo $n1;
?>