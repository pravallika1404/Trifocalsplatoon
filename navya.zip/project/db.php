<?php
	$conn=mysqli_connect("localhost","root","KP7306796743","project");
	if(!$conn)
	{
		die("Connection failed:".mysqli_connect_error());
	}
	else
	{
		//echo "connection is established";
	}