<?php
	$result=array();
	$result[]='hi';
	$result[]='bye';

	echo $result[0];
	echo "<br>".$result[1];
?>