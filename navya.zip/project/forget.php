<!DOCTYPE html>
<html>
<head>
	<title>PASSWORD</title>
	<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
	<link rel="stylesheet" type="text/css" href="forms.css">
</head>
<body>
<header>
	<nav>
		<ul>
			<li><a href="index.html">HOME</a></li>
		</ul>
	</nav>
</header>
	<h2>GRADUATE CAREER WEBSITE</h2>
	
<form method="POST" action="">

	<div>
		<span> ENTER YOUR EMAIL:</span><input type="mail" name="uid" required/><br>
	
	</div>
		
	<button type="submit">MAIL</button>
</form>

</body>
</html>